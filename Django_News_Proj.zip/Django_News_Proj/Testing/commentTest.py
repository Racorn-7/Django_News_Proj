from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time

PATH = "/Users/aziz/Desktop/chromedriverfinal"
driver = webdriver.Chrome(PATH)
USERNAME = 'aziz.alnuaimi@gmail.com'
PASSWORD = '055050'


driver.get('http://localhost:8000/login')
user_input = driver.find_element_by_id('id_username')
user_input.send_keys(USERNAME)
time.sleep(1)



password_input = driver.find_element_by_id('id_password')
password_input.send_keys(PASSWORD)
time.sleep(1)


login_button = driver.find_element_by_class_name('btn-outline-info')
time.sleep(1)
login_button.click()


article_button = driver.find_element_by_class_name("article-title")
time.sleep(1)
article_button.click()

html = driver.find_element_by_tag_name('html')
html.send_keys(Keys.END)

id_content = driver.find_element_by_id("id_content")
id_content.send_keys('testing')
time.sleep(1)

post_comment = driver.find_element_by_class_name("btn.btn-outline-info.mt-2.float-right")
time.sleep(1)
post_comment.click()


html2 = driver.find_element_by_tag_name('html')
html2.send_keys(Keys.END)

delete_button = driver.find_elements_by_xpath("//*[contains(text(), 'Delete')]")
time.sleep(1)
delete_button[0].click()

html3 = driver.find_element_by_tag_name('html')
html3.send_keys(Keys.END)
