from selenium import webdriver
import time

PATH = "/Users/aziz/Desktop/chromedriverfinal"
driver = webdriver.Chrome(PATH)
USERNAME = 'aziz.alnuaimi@gmail.com'
PASSWORD = '055050'


driver.get('http://localhost:8000/login')
user_input = driver.find_element_by_id('id_username')
user_input.send_keys(USERNAME)
time.sleep(1)



password_input = driver.find_element_by_id('id_password')
password_input.send_keys(PASSWORD)
time.sleep(1)


login_button = driver.find_element_by_class_name('btn-outline-info')
login_button.click()
