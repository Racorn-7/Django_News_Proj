from selenium import webdriver
from random_username.generate import generate_username
import time
import unittest

PATH = "/Users/aziz/Desktop/chromedriverfinal"
driver = webdriver.Chrome(PATH)
generate_username(100)
count=8

newUser = 'testingaccount'
newEmail = 'testingaccount@test.com'
newDob = '2000-08-30'
newPass1 = '123hello123'
newPass2 = '123hello123'

driver.get('http://localhost:8000/register/')

user_input = driver.find_element_by_id('id_username')
time.sleep(1)
user_input.send_keys(newUser)

email_input = driver.find_element_by_id('id_email')
time.sleep(1)
email_input.send_keys(newEmail)


dob_input = driver.find_element_by_id('id_date_of_birth')
time.sleep(1)
dob_input.send_keys(newDob)


password1_input = driver.find_element_by_id('id_password1')
time.sleep(1)
password1_input.send_keys(newPass1)

password2_input = driver.find_element_by_id('id_password2')
time.sleep(1)
password2_input.send_keys(newPass2)


signup_button = driver.find_element_by_class_name('btn-outline-info')
time.sleep(1)
signup_button.click()

driver.get('http://localhost:8000/admin/')
time.sleep(1)

admin_email = driver.find_element_by_id('id_username')
time.sleep(1)

admin_email.send_keys('aziz.alnuaimi@gmail.com')
time.sleep(1)

admin_pass = driver.find_element_by_id('id_password')
time.sleep(1)

admin_pass.send_keys('055050')
time.sleep(1)


submit_button = driver.find_element_by_class_name('submit-row')
time.sleep(1)

submit_button.click()


driver.get('http://localhost:8000/admin/account/account/')



time.sleep(1)

testingaccount_button = driver.find_elements_by_xpath("//*[contains(text(), 'testingaccount@test.com')]")
time.sleep(1)
testingaccount_button[0].click()
time.sleep(1)

delete_link = driver.find_element_by_class_name('deletelink')
time.sleep(1)
delete_link.click()
time.sleep(1)

last_button = driver.find_element_by_tag_name('input[type="submit"]')
time.sleep(1)
last_button.click()
