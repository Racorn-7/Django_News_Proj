from django import forms
from blog.models import Account as User
from django.contrib.auth.forms import UserCreationForm
from .models import Profile
from blog.models import UserCategory, Category



class UserRegisterForm(UserCreationForm):
    # this class renders the registration sign up page
    class Meta:
        model = User
        fields = ['username', 'email', 'date_of_birth']
        date_of_birth = forms.DateField()


class UserUpdateForm(forms.ModelForm):
    # this class renders the profile info update section
    class Meta:
        model = User
        fields = ['username', 'email', 'date_of_birth']
        date_of_birth = forms.DateField()


class ProfileUpdateForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = ['image', 'categories']

