from django.shortcuts import render, get_object_or_404
from django.urls import reverse
from django.views.generic import ListView, DetailView, CreateView, View
from django.views.generic.edit import FormMixin
from django.http import HttpResponseRedirect
from blog.models import Article, Category, Comment
from blog.forms import NewCommentForm
from django.forms.models import model_to_dict
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required


def BlogPostLike(request, pk):
    post = get_object_or_404(Article, id=request.POST.get('article_id'))
    if post.likes.filter(id=request.user.id).exists():
        post.likes.remove(request.user)
    else:
        post.likes.add(request.user)
    return HttpResponseRedirect(reverse('article-detail', args=[str(pk)]))


@login_required
def home(request):
    context = {
        'article': Article.objects.all(),
        'category': Category.objects.all(),
    }
    return render(request, 'blog/home.html', context)


class ArticleListView(ListView):
    model = Article
    template_name = 'blog/home.html'  # TemplateDoesNotExist: blog/article_list.html
    context_object_name = 'article'
    extra_context = {
        'category': Category.objects.all()
    }
    ordering = ['-date_published']


class ArticleDetailView(FormMixin, DetailView):
    template_name = 'blog/article_detail.html'
    model = Article
    form_class = NewCommentForm

    def get_success_url(self):
        return reverse('article-detail', kwargs={'pk': self.object.pk})

    def get_context_data(self, **kwargs):
        context = super(ArticleDetailView, self).get_context_data(**kwargs)
        likes_connected = get_object_or_404(Article, id=self.kwargs['pk'])
        liked = False
        if likes_connected.likes.filter(id=self.request.user.id).exists():
            liked = True
        context['number_of_likes'] = likes_connected.number_of_likes()
        context['post_is_liked'] = liked
        context['form'] = NewCommentForm()
        context['all_comments'] = Comment.objects.filter(article_id=self.object.pk).filter(parent=None)
        context['category'] = Category.objects.all()
        return context

    def post(self, request, *args, **kwargs):
        self.object = self.get_object()
        form = self.get_form()
        if form.is_valid():
            return self.form_valid(form, request)
        else:
            return self.form_invalid(form)

    def form_valid(self, form, request):
        content = form.cleaned_data.get('content')
        parent_obj = None
        try:
            parent_id = request.POST.get("parent_id")
        except:
            parent_id = None
        if parent_id:
            parent_queryset = Comment.objects.filter(id=parent_id)
            if parent_queryset.exists():
                parent_obj = parent_queryset.first()
        newcomment = Comment.objects.get_or_create(
            author=request.user,
            article_id=Article.objects.get(pk=self.kwargs['pk']),
            content=content,
            parent=parent_obj,
        )
        return super(ArticleDetailView, self).form_valid(form)
        data = super().get_context_data(**kwargs)


def about(request):
    return render(request, 'blog/about.html', {'title': 'About'})


def CategoryView(request, cats):
    category_posts = Article.objects.filter(category=cats)
    context = {
        'cats': cats,
        'category_posts': category_posts,
        'category': Category.objects.all(),
    }
    return render(request, 'blog/categories.html', context)


# class CommentList(View):
#     def get(self, request):
#         comments =  list(Comment.objects.all().values())
#         data =  dict()
#         data['comments'] = comments
#         return JsonResponse(data)

# class CommentCreate(CreateView):
#     def post(self, request):
#         data =  dict()
#         form = NewCommentForm(request.POST)
#         if form.is_valid():
#             comment = form.save()
#             data['comment'] = model_to_dict(comment)
#         else:
#             data['error'] =  "form not valid!"
#         return JsonResponse(data)

# class CommentUpdate(View):
#     def post(self, request, pk):
#         data =  dict()
#         comment = Comment.objects.get(pk=pk)
#         form = NewCommentForm(instance=comment, data=request.POST)
#         if form.is_valid():
#             comment = form.save()
#             data['comment'] = model_to_dict(comment)
#         else:
#             data['error'] =  "form not valid!"
#         return JsonResponse(data)

# class CommentDelete(View):
#     def post(self, request, pk):
#         data =  dict()
#         comment = Comment.objects.get(pk=pk)
#         if comment:
#             comment.delete()
#             data['message'] =  "Room deleted!"
#         else:
#             data['message'] =  "Error!"
#         return JsonResponse(data)

def CommentDelete(request, pk, id):
    comment = Comment.objects.get(id=id)
    comment.delete()
    return HttpResponseRedirect(reverse('article-detail', args=[str(pk)]))


def CommentEdit(request, pk, id):
    if request.method == 'POST':
        comment = Comment.objects.get(id=id)
        form = NewCommentForm(instance=comment, data=request.POST)
        if form.is_valid():
            form.save()
    return HttpResponseRedirect(reverse('article-detail', args=[str(pk)]))
