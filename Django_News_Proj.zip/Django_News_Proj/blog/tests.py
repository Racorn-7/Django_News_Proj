import time
from channels.testing import ChannelsLiveServerTestCase
from selenium import webdriver
from selenium.webdriver.common.keys import Keys


#NOTICE incase this code does not run access the files in folder testing
class websiteTest(ChannelsLiveServerTestCase):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.chrome = webdriver.Chrome()
        cls.chrome.implicitly_wait(10)

    @classmethod
    def tearDownClass(cls):
        cls.chrome.quit()
        super().tearDownClass()

    def allTest(self):
        try:
            USERNAME = 'aziz.alnuaimi@gmail.com'
            PASSWORD = '055050'
            self._login(USERNAME, PASSWORD)
            self._signUp()
            self._like()
            self._comment()
        except:
            pass

    def _login(self, USERNAME, PASSWORD):
        self.chrome.get('https://group60-group60.apps.okd.eecs.qmul.ac.uk/login/')
        user_input = self.chrome.find_element_by_id('id_username')
        user_input.send_keys(USERNAME)
        time.sleep(1)

        password_input = self.chrome.find_element_by_id('id_password')
        password_input.send_keys(PASSWORD)
        time.sleep(1)

        login_button = self.chrome.find_element_by_class_name('btn-outline-info')
        login_button.click()

    def _signUp(self):
        newUser = 'testingaccount'
        newEmail = 'testingaccount@test.com'
        newDob = '2000-08-30'
        newPass1 = '123hello123'
        newPass2 = '123hello123'

        self.chrome.get('https://group60-group60.apps.okd.eecs.qmul.ac.uk/login/')

        user_input = self.chrome.find_element_by_id('id_username')
        time.sleep(1)
        user_input.send_keys(newUser)

        email_input = self.chrome.find_element_by_id('id_email')
        time.sleep(1)
        email_input.send_keys(newEmail)

        dob_input = self.chrome.find_element_by_id('id_date_of_birth')
        time.sleep(1)
        dob_input.send_keys(newDob)

        password1_input = self.chrome.find_element_by_id('id_password1')
        time.sleep(1)
        password1_input.send_keys(newPass1)

        password2_input = self.chrome.find_element_by_id('id_password2')
        time.sleep(1)
        password2_input.send_keys(newPass2)

        signup_button = self.chrome.find_element_by_class_name('btn-outline-info')
        time.sleep(1)
        signup_button.click()

        self.chrome.get('https://group60-group60.apps.okd.eecs.qmul.ac.uk/admin/login/?next=/admin/')
        time.sleep(1)

        admin_email = self.chrome.find_element_by_id('id_username')
        time.sleep(1)

        admin_email.send_keys('aziz.alnuaimi@gmail.com')
        time.sleep(1)

        admin_pass = self.chrome.find_element_by_id('id_password')
        time.sleep(1)

        admin_pass.send_keys('055050')
        time.sleep(1)

        submit_button = self.chrome.find_element_by_class_name('submit-row')
        time.sleep(1)

        submit_button.click()

        self.chrome.get('https://group60-group60.apps.okd.eecs.qmul.ac.uk/admin/login/?next=/admin/account/account/')

        time.sleep(1)

        testingaccount_button = self.chrome.find_elements_by_xpath("//*[contains(text(), 'testingaccount@test.com')]")
        time.sleep(1)
        testingaccount_button[0].click()
        time.sleep(1)

        delete_link = self.chrome.find_element_by_class_name('deletelink')
        time.sleep(1)
        delete_link.click()
        time.sleep(1)

        last_button = self.chrome.find_element_by_tag_name('input[type="submit"]')
        time.sleep(1)
        last_button.click()

    def _like(self):
        USERNAME = 'aziz.alnuaimi@gmail.com'
        PASSWORD = '055050'

        self.chrome.get('https://group60-group60.apps.okd.eecs.qmul.ac.uk/login/')
        user_input = self.chrome.find_element_by_id('id_username')
        user_input.send_keys(USERNAME)
        time.sleep(1)

        password_input = self.chrome.find_element_by_id('id_password')
        password_input.send_keys(PASSWORD)
        time.sleep(1)

        login_button = self.chrome.find_element_by_class_name('btn-outline-info')
        login_button.click()
        time.sleep(1)

        article_button = self.chrome.find_element_by_class_name("article-title")
        article_button.click()
        time.sleep(1)

        article_like_button = self.chrome.find_element_by_name("article_id")
        article_like_button.click()
        time.sleep(1)

    def _comment(self):

        USERNAME = 'aziz.alnuaimi@gmail.com'
        PASSWORD = '055050'

        self.chrome.get('https://group60-group60.apps.okd.eecs.qmul.ac.uk/login/')
        user_input = self.chrome.find_element_by_id('id_username')
        user_input.send_keys(USERNAME)
        time.sleep(1)

        password_input = self.chrome.find_element_by_id('id_password')
        password_input.send_keys(PASSWORD)
        time.sleep(1)

        login_button = self.chrome.find_element_by_class_name('btn-outline-info')
        time.sleep(1)
        login_button.click()

        article_button = self.chrome.find_element_by_class_name("article-title")
        time.sleep(1)
        article_button.click()

        html = self.chrome.find_element_by_tag_name('html')
        html.send_keys(Keys.END)

        id_content = self.chrome.find_element_by_id("id_content")
        id_content.send_keys('testing')
        time.sleep(1)

        post_comment = self.chrome.find_element_by_class_name("btn.btn-outline-info.mt-2.float-right")
        time.sleep(1)
        post_comment.click()

        html2 = self.chrome.find_element_by_tag_name('html')
        html2.send_keys(Keys.END)

        delete_button = self.chrome.find_elements_by_xpath("//*[contains(text(), 'Delete')]")
        time.sleep(1)
        delete_button[0].click()

        html3 = self.chrome.find_element_by_tag_name('html')
        html3.send_keys(Keys.END)


# Create your tests here.
