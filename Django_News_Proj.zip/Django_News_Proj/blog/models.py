from django.db import models

# Create your models here.
from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager
from django.urls import reverse
from account.models import Account
from datetime import datetime


class Category(models.Model):
    name = models.CharField(max_length=200)

    def __str__(self):
        return self.name


class Article(models.Model):
    title = models.CharField(max_length=200)
    content = models.TextField(max_length=20000)
    date_published = models.DateField(auto_now_add=False)
    photo = models.ImageField(upload_to='article_pics', null=True)
    likes = models.ManyToManyField(Account, related_name='blogpost_like')
    category = models.CharField(max_length=255, default='None')
    category_id = models.ForeignKey(Category, related_name='article', on_delete=models.CASCADE, null=True)

    def __str__(self):
        return self.title

    def number_of_likes(self):
        return self.likes.count()

    def get_absolute_url(self):
        return reverse('post-detail', kwargs={'pk': self.pk})


class UserArticle(models.Model):
    article_id = models.ForeignKey(Article, on_delete=models.CASCADE)
    user_id = models.ForeignKey(Account, on_delete=models.CASCADE)

    def __str__(self):
        return self.user_id.username + " reads on: " + self.article_id.title


class UserCategory(models.Model):
    user_id = models.ForeignKey(Account, on_delete=models.CASCADE)
    category_id = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='userc')

    def __str__(self):
        return self.user_id.username + " follows : " + self.category_id.name


class Comment(models.Model):
    author = models.ForeignKey(Account, on_delete=models.CASCADE)
    article_id = models.ForeignKey(Article, on_delete=models.CASCADE)
    parent = models.ForeignKey('self', on_delete=models.SET_NULL, null=True)
    content = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-timestamp']

    def __str__(self):
        return str(self.author.username)+": "+str(self.article_id)

    def children(self): #returns comment replies
        return Comment.objects.filter(parent=self)

    @property
    def is_parent(self):
        if self.parent is not None:
            return False
        return True
