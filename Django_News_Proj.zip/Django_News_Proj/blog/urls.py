from django.urls import path
from . import views
from .views import *
urlpatterns = [
    path('', ArticleListView.as_view(), name='blog-home'),
    path('article/<int:pk>', ArticleDetailView.as_view(), name='article-detail'),
    path('like/<int:pk>', views.BlogPostLike, name='blogpost_like'),
    path('about/', views.about, name='blog-about'),
    path('category/<str:cats>/', CategoryView, name='category'),
    path('comment/delete/<int:pk>/<int:id>', views.CommentDelete, name='comment_delete'),
    path('comment/edit/<int:pk>/<int:id>', views.CommentEdit, name='comment_edit'),
]

# style="background-image: url('{{ post.photo.url}}')"

